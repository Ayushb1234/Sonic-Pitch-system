# -----------------------------
# app.py
# FastAPI backend for Vocal Mirror
# -----------------------------
import os, uuid, traceback, shutil
from pathlib import Path
from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from analysis import compare_files

# Debug flag (set DEBUG=0 in prod)
DEBUG = os.getenv("DEBUG", "1") == "1"

app = FastAPI(title="Vocal Mirror API", version="0.2")

# CORS middleware (open for local dev, restrict in prod)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Temp upload directory
TMP_DIR = Path("tmp")
TMP_DIR.mkdir(parents=True, exist_ok=True)


def safe_name(name: str) -> str:
    """Sanitize filename to avoid path traversal or special chars."""
    if not name:
        return "noname"
    name = name.replace("\\", "/").split("/")[-1]
    return "".join(ch for ch in name if ch.isalnum() or ch in ("_", "-", ".", " "))


async def save_upload(file: UploadFile, prefix: str) -> Path:
    """Save an uploaded file safely to tmp directory with unique name."""
    fname = f"{prefix}_{uuid.uuid4().hex}_{safe_name(file.filename)}"
    path = TMP_DIR / fname
    with open(path, "wb") as out:
        while chunk := await file.read(1024 * 1024):  # 1 MB chunks
            out.write(chunk)
    await file.close()
    return path


@app.post("/analyze")
async def analyze(reference: UploadFile = File(...), user: UploadFile = File(...)):
    ref_path = usr_path = None
    try:
        # Save uploads to disk
        ref_path = await save_upload(reference, "ref")
        usr_path = await save_upload(user, "usr")

        # Run analysis
        report = compare_files(str(ref_path), str(usr_path))
        return JSONResponse(report)

    except Exception as e:
        tb = traceback.format_exc()
        print("ANALYZE_ERROR:\n", tb)
        payload = {"error": str(e)}
        if DEBUG:
            payload["traceback"] = tb
        return JSONResponse(payload, status_code=500)

    finally:
        # Clean up tmp files
        for p in (ref_path, usr_path):
            try:
                if p and p.exists():
                    p.unlink()
            except Exception:
                pass
