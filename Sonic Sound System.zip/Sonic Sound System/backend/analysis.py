# -----------------------------
# analysis.py (Pro - hardened)
# -----------------------------

from __future__ import annotations
import os
from dataclasses import dataclass
import numpy as np
import librosa
from librosa.sequence import dtw
from pydub import AudioSegment

# ---------- Tunables ----------
FAST_MODE = os.getenv("FAST_ANALYSIS", "0") == "1"
SR = 8000 if FAST_MODE else 22050
HOP = 512 if FAST_MODE else 256
FRAME_LENGTH = 2048
PITCH_MIN = librosa.note_to_hz('C2')
PITCH_MAX = librosa.note_to_hz('C7')
CENTS_RED = 30
MIN_RED_FRAMES = 12
TIMING_RED_MS = 90
MAX_SECONDS = float(os.getenv("MAX_ANALYSIS_SEC", "0"))  # 0 = full

@dataclass
class SegmentTip:
    start_s: float
    end_s: float
    issue: str
    suggestion: str
    severity: float

# ---------- Utilities ----------

def to_wav_mono_22k(src_path: str) -> str:
    """Convert any audio to mono 22.05k WAV via ffmpeg/pydub."""
    try:
        dst_path = os.path.splitext(src_path)[0] + "_norm.wav"
        audio = AudioSegment.from_file(src_path)
        audio = audio.set_channels(1).set_frame_rate(22050)
        audio.export(dst_path, format="wav")
        return dst_path
    except Exception as e:
        raise RuntimeError(
            "Audio conversion failed (ffmpeg not installed or bad input). "
            "Install FFmpeg and ensure it's on PATH."
        ) from e

def load_mono(path: str, sr: int = SR):
    kwargs = dict(sr=sr, mono=True)
    if MAX_SECONDS > 0:
        kwargs.update(duration=MAX_SECONDS)
    y, _ = librosa.load(path, **kwargs)
    if y.size:
        y = librosa.util.normalize(y)
    return y, sr

def assert_audio(y: np.ndarray, name: str):
    if y is None or not isinstance(y, np.ndarray) or y.size == 0:
        raise ValueError(f"{name}: decoded audio is empty. Use a clean WAV/MP3.")
    if not np.isfinite(y).any():
        raise ValueError(f"{name}: audio has no finite samples.")

def pre_emphasis(y: np.ndarray, coef: float = 0.97):
    return librosa.effects.preemphasis(y, coef=coef)

def extract_pitch(y: np.ndarray, sr: int):
    f0, vflag, _ = librosa.pyin(
        y, fmin=PITCH_MIN, fmax=PITCH_MAX,
        frame_length=FRAME_LENGTH, hop_length=HOP
    )
    if f0 is None:
        return np.full(1, np.nan)
    f0[~vflag] = np.nan
    return f0

def interp_nans(arr: np.ndarray):
    arr = np.asarray(arr, dtype=float)
    out = arr.copy()
    if out.size == 0:
        return out
    nans = np.isnan(out)
    if np.all(nans):
        return np.zeros_like(out)
    idx = np.flatnonzero(~nans)
    out[nans] = np.interp(np.flatnonzero(nans), idx, out[idx])
    return out

def cents(hz, ref_hz):
    with np.errstate(divide='ignore', invalid='ignore'):
        return 1200.0 * np.log2(hz / ref_hz)

def build_feat(y: np.ndarray, sr: int, f0: np.ndarray):
    # returns (T x D)
    mel = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=64, hop_length=HOP)
    logmel = librosa.power_to_db(mel, ref=np.max)           # (64, T)
    f0i = interp_nans(f0)                                   # (T,)
    f0z = (f0i - np.mean(f0i)) / (np.std(f0i) + 1e-6)
    feat = np.vstack([logmel, np.atleast_2d(f0z)])          # (65, T)
    return feat.T                                           # (T, 65)

def ensure_2d_feat(F, name):
    F = np.asarray(F)
    if F.ndim != 2:
        raise ValueError(f"{name} must be 2D, got shape {F.shape}")
    if F.shape[0] < 2 or F.shape[1] < 2:
        raise ValueError(f"{name} too small for DTW, shape {F.shape}")
    if not np.isfinite(F).any():
        raise ValueError(f"{name} has no finite values")
    return F

def pair_onsets(y_ref, y_usr, sr):
    on_ref = librosa.onset.onset_detect(y=y_ref, sr=sr, hop_length=HOP, units='time')
    on_usr = librosa.onset.onset_detect(y=y_usr, sr=sr, hop_length=HOP, units='time')
    m = min(len(on_ref), len(on_usr))
    if m == 0:
        return np.array([]), np.array([]), np.array([])
    delta = on_usr[:m] - on_ref[:m]
    return on_ref[:m], on_usr[:m], 1000.0 * delta  # ms

def scan_red_segments(idx_ref, ce_aligned, sr=SR, hop=HOP):
    bad = np.abs(ce_aligned) > CENTS_RED
    tips: list[SegmentTip] = []
    if not np.any(bad):
        return tips
    edges = np.diff(bad.astype(int), prepend=0, append=0)
    starts = np.where(edges == 1)[0]
    ends = np.where(edges == -1)[0] - 1
    for s, e in zip(starts, ends):
        if (e - s + 1) < MIN_RED_FRAMES: continue
        mean_abs = float(np.nanmean(np.abs(ce_aligned[s:e+1])))
        dur_s = (e - s + 1) * hop / sr
        sev = mean_abs * dur_s
        t0 = idx_ref[s] * hop / sr
        t1 = (idx_ref[e] + 1) * hop / sr
        mean_signed = float(np.nanmean(ce_aligned[s:e+1]))
        if mean_signed > 0:
            issue = f"{mean_abs:.0f} cents sharp"
            suggestion = "Pitch thoda neeche lao (slide down) aur lock karo."
        else:
            issue = f"{mean_abs:.0f} cents flat"
            suggestion = "Pitch thoda upar lao (slide up) aur hold steady."
        tips.append(SegmentTip(t0, t1, issue, suggestion, sev))
    tips.sort(key=lambda x: x.severity, reverse=True)
    return tips

# ---------- Advanced metrics (unchanged logic) ----------

def voiced_percent(f0):
    valid = np.isfinite(f0)
    return float(100 * np.mean(valid)) if f0.size else 0.0

def pitch_drift_cents_per_min(ce_aligned, sr, hop):
    if ce_aligned.size < 8: return 0.0
    t = np.arange(len(ce_aligned)) * hop / sr / 60.0
    ce = np.nan_to_num(ce_aligned, nan=0.0)
    b, a = np.polyfit(t, ce, 1)
    return float(b)

def note_wise_errors(f0r_al, ce_aligned):
    out = []
    voiced = np.isfinite(f0r_al) & np.isfinite(ce_aligned)
    if not np.any(voiced):
        return out
    midi = librosa.hz_to_midi(f0r_al[voiced])
    cents_err = np.abs(ce_aligned[voiced])
    midi_round = np.rint(midi).astype(int)
    uniq = np.unique(midi_round)
    for m in uniq:
        sel = midi_round == m
        if np.sum(sel) < 8:
            continue
        med = float(np.median(cents_err[sel]))
        cnt = int(np.sum(sel))
        out.append({"midi": int(m), "note": librosa.midi_to_note(m),
                    "median_abs_cents": med, "count": cnt})
    out.sort(key=lambda d: d["median_abs_cents"], reverse=True)
    return out[:8]

def smoothness_mad_cents(f0u_al, sr, hop):
    x = np.nan_to_num(f0u_al, nan=0.0)
    if x.size < 3: return 0.0
    med = np.median(x[x>0]) if np.any(x>0) else 1.0
    ce = cents(np.maximum(x,1e-6), med)
    d = np.abs(np.diff(ce))
    return float(np.median(d))

def tempo_and_alignment(y_ref, y_usr, sr, on_ref, on_usr, timing_err_ms):
    tempo_r = float(librosa.beat.tempo(y=y_ref, sr=sr, hop_length=HOP, aggregate=np.median))
    tempo_u = float(librosa.beat.tempo(y=y_usr, sr=sr, hop_length=HOP, aggregate=np.median))
    tempo_dev_pct = float(100.0 * (tempo_u - tempo_r) / max(tempo_r, 1e-6))
    if timing_err_ms.size:
        early = int(np.sum(timing_err_ms < -TIMING_RED_MS))
        late  = int(np.sum(timing_err_ms >  TIMING_RED_MS))
        mean  = float(np.mean(timing_err_ms))
        std   = float(np.std(timing_err_ms))
        mae   = float(np.mean(np.abs(timing_err_ms)))
        if mae <= 40: balign = 100
        elif mae <= 90: balign = int(np.interp(mae,[40,90],[100,60]))
        elif mae <= 160: balign = int(np.interp(mae,[90,160],[60,30]))
        else: balign = 10
        tmin = (on_ref[:len(timing_err_ms)]/60.0) if on_ref.size else (np.arange(len(timing_err_ms))/60.0)
        b, _a = np.polyfit(tmin, timing_err_ms, 1) if len(tmin)>=2 else (0.0,0.0)
        lag_slope = float(b)
    else:
        early=late=0; mean=std=0.0; balign=0; lag_slope=0.0
    return {
        "tempo_ref_bpm": tempo_r, "tempo_user_bpm": tempo_u, "tempo_dev_pct": tempo_dev_pct,
        "onset_early_count": early, "onset_late_count":  late,
        "onset_mean_ms": mean, "onset_std_ms": std,
        "beat_alignment_score": balign, "lag_trend_ms_per_min": lag_slope
    }

def spectral_centroid_corr(y_ref, y_usr, sr, idx_ref, idx_usr):
    # Compute per-frame spectral centroid
    cen_r = librosa.feature.spectral_centroid(y=y_ref, sr=sr, hop_length=HOP).flatten()
    cen_u = librosa.feature.spectral_centroid(y=y_usr, sr=sr, hop_length=HOP).flatten()

    # Safety: clamp DTW indices to centroid array lengths
    idx_ref_c, idx_usr_c = clamp_indices(
        np.asarray(idx_ref, dtype=int),
        np.asarray(idx_usr, dtype=int),
        len(cen_r),
        len(cen_u)
    )

    # Align sequences via clamped indices
    cen_r_al = cen_r[idx_ref_c]
    cen_u_al = cen_u[idx_usr_c]

    # Guard against degenerate variance (corr undefined)
    if np.std(cen_r_al) < 1e-8 or np.std(cen_u_al) < 1e-8:
        return 0.0, 0.0

    corr = float(np.corrcoef(cen_r_al, cen_u_al)[0, 1])
    diff = float(np.mean(np.abs(cen_r_al - cen_u_al)))
    return corr, diff


def hnr_proxy_db(y):
    harm, _perc = librosa.effects.hpss(y, margin=(2.0,1.0))
    resid = y - harm
    rms_h = np.sqrt(np.mean(harm**2) + 1e-12)
    rms_n = np.sqrt(np.mean(resid**2) + 1e-12)
    return float(20*np.log10(rms_h / max(rms_n,1e-12)))

def band_energy_split(y, sr):
    S = np.abs(librosa.stft(y, n_fft=2048, hop_length=HOP))
    freqs = librosa.fft_frequencies(sr=sr, n_fft=2048)
    bands = [(0,300),(300,3000),(3000, sr/2)]
    out = []
    total = np.sum(S**2) + 1e-12
    for lo, hi in bands:
        sel = (freqs>=lo)&(freqs<hi)
        frac = float(np.sum((S[sel])**2)/total)
        out.append(frac)
    return {"low": out[0], "mid": out[1], "high": out[2]}

def dynamics_stats(y_ref, y_usr, sr, idx_ref, idx_usr):
    rms_r = librosa.feature.rms(y=y_ref, hop_length=HOP).flatten()
    rms_u = librosa.feature.rms(y=y_usr, hop_length=HOP).flatten()
    r_al = rms_r[idx_ref]; u_al = rms_u[idx_usr]
    def dyn_range_db(x):
        p10, p90 = np.percentile(x,10), np.percentile(x,90)
        return float(20*np.log10((p90+1e-9)/(p10+1e-9)))
    dr_r = dyn_range_db(rms_r); dr_u = dyn_range_db(rms_u)
    r_corr = float(np.corrcoef(r_al, u_al)[0,1]) if np.std(r_al)>1e-8 and np.std(u_al)>1e-8 else 0.0
    dr_al = np.diff(r_al); du_al = np.diff(u_al)
    cresc_corr = float(np.corrcoef(dr_al, du_al)[0,1]) if np.std(dr_al)>1e-8 and np.std(du_al)>1e-8 else 0.0
    return {"rms_corr": r_corr,
            "dyn_range_db_ref": dr_r, "dyn_range_db_user": dr_u,
            "dyn_range_db_diff": float(abs(dr_r - dr_u)),
            "crescendo_corr": cresc_corr}

def attack_time_ms(y, sr, onsets_sec):
    rms = librosa.feature.rms(y=y, hop_length=HOP).flatten()
    times = librosa.frames_to_time(np.arange(len(rms)), sr=sr, hop_length=HOP)
    out=[]
    for t in onsets_sec:
        t0=t; t1=t+0.2
        sel = (times>=t0)&(times<=t1)
        if np.sum(sel)<3: continue
        seg=rms[sel]
        lo = np.min(seg); hi=np.max(seg)
        a10 = lo + 0.1*(hi-lo)
        a90 = lo + 0.9*(hi-lo)
        i10 = np.argmax(seg>=a10)
        i90 = np.argmax(seg>=a90)
        dt = max(i90 - i10, 0) * HOP / sr * 1000.0
        out.append(dt)
    return float(np.median(out)) if out else None

def sustain_length_deviation(on_ref, on_usr):
    if len(on_ref)<2 or len(on_usr)<2: return None
    dr = np.diff(on_ref)*1000.0
    du = np.diff(on_usr)*1000.0
    m = min(len(dr), len(du))
    return float(np.median(np.abs(du[:m]-dr[:m])))

def vibrato_stats(f0_al, sr, hop):
    x = np.nan_to_num(f0_al, nan=0.0)
    if np.count_nonzero(x) < 16:
        return {"rate_hz": None, "depth_cents": None}
    med = np.median(x[x>0]) if np.any(x>0) else 1.0
    ce = cents(np.maximum(x,1e-6), med)
    win = max(3, int(0.25 * sr / hop))
    k = np.ones(win)/win
    trend = np.convolve(ce, k, mode='same')
    d = ce - trend
    fs = sr / hop
    X = np.abs(np.fft.rfft(d))
    freqs = np.fft.rfftfreq(len(d), d=1.0/fs)
    band = (freqs>=4.0)&(freqs<=8.0)
    if not np.any(band):
        return {"rate_hz": None, "depth_cents": None}
    i = np.argmax(X[band])
    rate = float(freqs[band][i])
    depth = float(np.std(d[~np.isnan(d)]))
    return {"rate_hz": rate, "depth_cents": depth}

def section_summaries(idx_ref, sr, hop, ce_aligned, timing_err_ms):
    n = len(ce_aligned)
    if n < 60:
        return []
    slices = np.array_split(np.arange(n), 6)
    out=[]
    for sl in slices:
        ce = ce_aligned[sl]
        t0 = sl[0]*hop/sr
        t1 = (sl[-1]+1)*hop/sr
        pitch_med = float(np.nanmedian(np.abs(ce[np.isfinite(ce)]))) if np.any(np.isfinite(ce)) else 0.0
        out.append({"start_s": float(t0), "end_s": float(t1), "median_pitch_cents": pitch_med})
    return out

# ---------- DTW helpers ----------

def ensure_warp_path(wp):
    """Normalize librosa DTW path to shape (L, 2) and reverse to time order."""
    wp = np.asarray(wp, dtype=int)
    if wp.ndim != 2:
        raise ValueError(f"Unexpected DTW path ndim: {wp.ndim}, shape={wp.shape}")
    # accept (L,2) or (2,L)
    if wp.shape[1] == 2:
        path = wp
    elif wp.shape[0] == 2:
        path = wp.T
    else:
        raise ValueError(f"Unexpected DTW path shape: {wp.shape}")
    if path.shape[0] == 0:
        raise ValueError("DTW produced empty path. Audio too short or silent?")
    return path[::-1]  # reverse to chronological

def clamp_indices(idx_ref, idx_usr, len_ref, len_usr):
    """Drop any pairs that go out of bounds to avoid IndexError."""
    mask = (idx_ref >= 0) & (idx_ref < len_ref) & (idx_usr >= 0) & (idx_usr < len_usr)
    if not np.any(mask):
        raise ValueError("DTW indices are out of bounds after alignment.")
    return idx_ref[mask], idx_usr[mask]

# ---------- Main comparison ----------

def compare_files(reference_path: str, user_path: str):
    ref_norm = to_wav_mono_22k(reference_path)
    usr_norm = to_wav_mono_22k(user_path)

    try:
        # 1) Load
        y_ref, sr = load_mono(ref_norm, SR)
        y_usr, _  = load_mono(usr_norm, SR)
        assert_audio(y_ref, "reference")
        assert_audio(y_usr, "user")

        # 2) Pre-emphasis
        y_ref = pre_emphasis(y_ref); y_usr = pre_emphasis(y_usr)

        # 3) Pitch
        f0_ref = extract_pitch(y_ref, sr)
        f0_usr = extract_pitch(y_usr, sr)

        # 4) Features
        F_ref = ensure_2d_feat(build_feat(y_ref, sr, f0_ref), "F_ref")
        F_usr = ensure_2d_feat(build_feat(y_usr, sr, f0_usr), "F_usr")

        # 5) DTW
        _D, raw_wp = dtw(F_ref.T, F_usr.T, metric='cosine',
                         global_constraints="sakoe_chiba", band_rad=20)
        path = ensure_warp_path(raw_wp)
        idx_ref = np.array([i for (i,j) in path], dtype=int)
        idx_usr = np.array([j for (i,j) in path], dtype=int)

        # bounds safety for indexing f0/rms/centroid
        idx_ref, idx_usr = clamp_indices(idx_ref, idx_usr, len(f0_ref), len(f0_usr))

        # 6) Align pitches
        f0r_al = f0_ref[idx_ref]
        f0u_al = f0_usr[idx_usr]

        # 7) Key center
        voiced_mask = np.isfinite(f0r_al)
        ref_med = float(np.nanmedian(f0r_al[voiced_mask])) if np.any(voiced_mask) else float(np.nanmean(interp_nans(f0r_al)))

        # 8) Cents error (user - ref)
        ce_user = cents(f0u_al, ref_med)
        ce_ref  = cents(f0r_al, ref_med)
        ce_aligned = ce_user - ce_ref

        # 9) Onset timing
        on_ref, on_usr, timing_err_ms = pair_onsets(y_ref, y_usr, sr)

        # 10) Loudness similarity
        rms_ref = librosa.feature.rms(y=y_ref, hop_length=HOP).flatten()
        rms_usr = librosa.feature.rms(y=y_usr, hop_length=HOP).flatten()
        # clamp indices also for rms arrays
        idx_ref_rms, idx_usr_rms = clamp_indices(idx_ref, idx_usr, len(rms_ref), len(rms_usr))
        rms_ref_al = rms_ref[idx_ref_rms]; rms_usr_al = rms_usr[idx_usr_rms]
        loud_corr = float(np.corrcoef(rms_ref_al, rms_usr_al)[0,1]) if np.std(rms_ref_al)>1e-8 and np.std(rms_usr_al)>1e-8 else 0.0

        # 11) Stability
        def rolling_std(x, w):
            mu = np.convolve(x, np.ones(w)/w, mode='same')
            mu2 = np.convolve(x**2, np.ones(w)/w, mode='same')
            var = np.maximum(mu2 - mu**2, 0.0)
            return np.sqrt(var)
        stdev_cents = rolling_std(np.nan_to_num(ce_aligned, nan=0.0), 7)
        stability_med = float(np.nanmedian(stdev_cents[np.isfinite(stdev_cents)])) if np.any(np.isfinite(stdev_cents)) else 0.0

        # 12) Scores
        ce_vals = np.abs(ce_aligned[np.isfinite(ce_aligned)])
        pitch_med = float(np.nanmedian(ce_vals)) if ce_vals.size else 0.0
        pitch_p95 = float(np.nanpercentile(ce_vals, 95)) if ce_vals.size else 0.0
        timing_mae = float(np.mean(np.abs(timing_err_ms))) if timing_err_ms.size else None

        def map_pitch_score(med_cents):
            if med_cents <= 20: return 100
            if med_cents <= 50: return int(np.interp(med_cents,[20,50],[100,60]))
            if med_cents <= 100: return int(np.interp(med_cents,[50,100],[60,30]))
            if med_cents <= 150: return int(np.interp(med_cents,[100,150],[30,10]))
            return 5
        def map_time_score(mae_ms):
            if mae_ms is None: return 70
            if mae_ms <= 40: return 100
            if mae_ms <= 90: return int(np.interp(mae_ms,[40,90],[100,60]))
            if mae_ms <= 160: return int(np.interp(mae_ms,[90,160],[60,30]))
            return 10
        def map_stab_score(std_cents):
            if std_cents <= 10: return 100
            if std_cents <= 25: return int(np.interp(std_cents,[10,25],[100,60]))
            if std_cents <= 45: return int(np.interp(std_cents,[25,45],[60,30]))
            return 15
        def map_dyn_score(r):
            return int(np.clip((r+1)/2*100, 0, 100))

        S_pitch = map_pitch_score(pitch_med)
        S_time  = map_time_score(timing_mae)
        S_stab  = map_stab_score(stability_med)
        S_dyn   = map_dyn_score(loud_corr)
        overall = int(0.4*S_pitch + 0.3*S_time + 0.2*S_stab + 0.1*S_dyn)

        # 13) Coaching tips
        tips = scan_red_segments(idx_ref, ce_aligned, sr, HOP)[:3]

        # ---------- Deep diagnostics ----------
        deep = {}
        deep["pitch"] = {
            "voiced_percent_user": voiced_percent(f0u_al),
            "voiced_percent_ref":  voiced_percent(f0r_al),
            "drift_cents_per_min": pitch_drift_cents_per_min(ce_aligned, sr, HOP),
            "smoothness_mad_cents": smoothness_mad_cents(f0u_al, sr, HOP),
            "note_wise_errors": note_wise_errors(f0r_al, ce_aligned),
        }
        deep["timing"] = tempo_and_alignment(y_ref, y_usr, sr, on_ref, on_usr, timing_err_ms)
        cen_corr, cen_diff = spectral_centroid_corr(y_ref, y_usr, sr, idx_ref, idx_usr)
        def hnr_proxy_db(y):
            harm, _ = librosa.effects.hpss(y, margin=(2.0,1.0))
            resid = y - harm
            rms_h = np.sqrt(np.mean(harm**2) + 1e-12)
            rms_n = np.sqrt(np.mean(resid**2) + 1e-12)
            return float(20*np.log10(rms_h / max(rms_n,1e-12)))
        hnr_r = hnr_proxy_db(y_ref); hnr_u = hnr_proxy_db(y_usr)
        deep["timbre"] = {
            "spectral_centroid_corr": cen_corr,
            "spectral_centroid_mean_abs_diff": cen_diff,
            "hnr_db_ref": hnr_r,
            "hnr_db_user": hnr_u,
            "hnr_match_score": float(100 - min(abs(hnr_r - hnr_u), 30) / 30 * 100)
        }
        def band_energy_split(y, sr):
            S = np.abs(librosa.stft(y, n_fft=2048, hop_length=HOP))
            freqs = librosa.fft_frequencies(sr=sr, n_fft=2048)
            bands = [(0,300),(300,3000),(3000, sr/2)]
            out = []
            total = np.sum(S**2) + 1e-12
            for lo, hi in bands:
                sel = (freqs>=lo)&(freqs<hi)
                frac = float(np.sum((S[sel])**2)/total)
                out.append(frac)
            return {"low": out[0], "mid": out[1], "high": out[2]}
        deep["band_energy_fraction"] = {"ref": band_energy_split(y_ref, sr),
                                        "user": band_energy_split(y_usr, sr)}
        def attack_time_ms(y, sr, onsets_sec):
            rms = librosa.feature.rms(y=y, hop_length=HOP).flatten()
            times = librosa.frames_to_time(np.arange(len(rms)), sr=sr, hop_length=HOP)
            out=[]
            for t in onsets_sec:
                t0=t; t1=t+0.2
                sel = (times>=t0)&(times<=t1)
                if np.sum(sel)<3: continue
                seg=rms[sel]
                lo = np.min(seg); hi=np.max(seg)
                a10 = lo + 0.1*(hi-lo)
                a90 = lo + 0.9*(hi-lo)
                i10 = np.argmax(seg>=a10); i90 = np.argmax(seg>=a90)
                dt = max(i90 - i10, 0) * HOP / sr * 1000.0
                out.append(dt)
            return float(np.median(out)) if out else None
        def sustain_length_deviation(on_ref, on_usr):
            if len(on_ref)<2 or len(on_usr)<2: return None
            dr = np.diff(on_ref)*1000.0; du = np.diff(on_usr)*1000.0
            m = min(len(dr), len(du))
            return float(np.median(np.abs(du[:m]-dr[:m])))
        atk_ref = attack_time_ms(y_ref, sr, on_ref)
        atk_usr = attack_time_ms(y_usr, sr, on_usr)
        deep["articulation"] = {
            "attack_ms_ref": atk_ref,
            "attack_ms_user": atk_usr,
            "attack_ms_diff": None if (atk_ref is None or atk_usr is None) else float(abs(atk_ref - atk_usr)),
            "sustain_len_mae_ms": sustain_length_deviation(on_ref, on_usr)
        }
        def vibrato_stats(f0_al, sr, hop):
            x = np.nan_to_num(f0_al, nan=0.0)
            if np.count_nonzero(x) < 16:
                return {"rate_hz": None, "depth_cents": None}
            med = np.median(x[x>0]) if np.any(x>0) else 1.0
            ce = cents(np.maximum(x,1e-6), med)
            win = max(3, int(0.25 * sr / hop))
            k = np.ones(win)/win
            trend = np.convolve(ce, k, mode='same')
            d = ce - trend
            fs = sr / hop
            X = np.abs(np.fft.rfft(d))
            freqs = np.fft.rfftfreq(len(d), d=1.0/fs)
            band = (freqs>=4.0)&(freqs<=8.0)
            if not np.any(band):
                return {"rate_hz": None, "depth_cents": None}
            i = np.argmax(X[band])
            rate = float(freqs[band][i])
            depth = float(np.std(d[~np.isnan(d)]))
            return {"rate_hz": rate, "depth_cents": depth}
        vib_r = vibrato_stats(f0r_al, sr, HOP); vib_u = vibrato_stats(f0u_al, sr, HOP)
        deep["vibrato"] = {"rate_hz_ref": vib_r["rate_hz"], "rate_hz_user": vib_u["rate_hz"],
                           "depth_cents_ref": vib_r["depth_cents"], "depth_cents_user": vib_u["depth_cents"]}
        deep["sections"] = section_summaries(idx_ref, sr, HOP, ce_aligned, timing_err_ms)

        # ---------- Response ----------
        report = {
            "score": {"overall": overall, "pitch": S_pitch, "timing": S_time, "stability": S_stab, "dynamics": S_dyn},
            "metrics": {
                "median_pitch_error_cents": pitch_med,
                "p95_pitch_error_cents": pitch_p95,
                "timing_mae_ms": timing_mae,
                "loudness_corr": loud_corr,
                "stability_med_cents": stability_med
            },
            "top_tips": [{"start_s": float(t.start_s), "end_s": float(t.end_s), "issue": t.issue, "suggestion": t.suggestion} for t in scan_red_segments(idx_ref, ce_aligned, sr, HOP)[:3]],
            "viz": {
                "idx_ref": idx_ref.tolist(),
                "idx_usr": idx_usr.tolist(),
                "cents_error": np.nan_to_num(ce_aligned, nan=0.0).tolist(),
                "hop": HOP, "sr": SR
            },
            "deep": deep
        }
        return report

    finally:
        for p in [ref_norm, usr_norm]:
            try: os.remove(p)
            except: pass
