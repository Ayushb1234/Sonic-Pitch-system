import React from "react"
import Upload from "./components/Upload"
import ScoreCard from "./components/ScoreCard"
import PianoRoll from "./components/PianoRoll"

const API = "http://127.0.0.1:8000"

export default function App() {
  const [refFile, setRef] = React.useState<File|null>(null)
  const [usrFile, setUsr] = React.useState<File|null>(null)
  const [loading, setLoading] = React.useState(false)
  const [data, setData] = React.useState<any|null>(null)

  const canAnalyze = !!refFile && !!usrFile && !loading

  async function analyze() {
    if (!refFile || !usrFile) return
    setLoading(true)
    setData(null)
    try {
      const form = new FormData()
      form.append("reference", refFile)
      form.append("user", usrFile)
      const res = await fetch(`${API}/analyze`, { method:"POST", body: form })
      if (!res.ok) {
        const txt = await res.text()
        setData({ error: `HTTP ${res.status} – ${txt.slice(0,200)}` })
        return
      }
      const j = await res.json()
      setData(j)
    } catch (e) {
      setData({ error: String(e) })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container">
      <h1>🎤 Vocal Mirror</h1>
      <p className="small">Reference singer vs aapki singing compare + coaching tips.</p>

      <Upload onChange={(r,u)=>{ setRef(r); setUsr(u) }} />

      <div className="row">
        <button onClick={analyze} disabled={!canAnalyze}>
          {loading ? "Analyzing…" : "Analyze"}
        </button>
        <span className="small">Quiet room + headset mic recommended.</span>
      </div>

      {data?.error && <div className="card bad">Error: {data.error}</div>}

      {data && !data.error && (
        <>
          <ScoreCard score={data.score} metrics={data.metrics} />
          <PianoRoll viz={data.viz} />
        </>
      )}
    </div>
  )
}
