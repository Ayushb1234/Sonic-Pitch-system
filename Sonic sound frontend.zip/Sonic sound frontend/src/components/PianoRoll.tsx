import React from "react"

type Viz = {
  idx_ref: number[]
  idx_usr: number[]
  cents_error: number[]
  hop: number
  sr: number
}

export default function PianoRoll({ viz }: { viz: Viz | null }) {
  const ref = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    // guard: need element + non-empty data
    if (!viz || !ref.current) return
    if (
      !Array.isArray(viz.idx_ref) || viz.idx_ref.length === 0 ||
      !Array.isArray(viz.cents_error) || viz.cents_error.length === 0 ||
      !viz.sr || !viz.hop
    ) return

    const el = ref.current
    el.innerHTML = "" // reset

    // total duration in seconds (aligned to last ref frame)
    const lastIdx = viz.idx_ref[viz.idx_ref.length - 1]
    if (typeof lastIdx !== "number" || lastIdx < 0) return

    const T = (lastIdx * viz.hop) / viz.sr
    if (!isFinite(T) || T <= 0) return

    // grid ticks each 1s
    for (let t = 0; t <= Math.floor(T); t += 1) {
      const div = document.createElement("div")
      div.className = "tick"
      div.style.left = `${(t / T) * 100}%`
      el.appendChild(div)
    }

    // draw error bands where |cents_error| > 30
    const THRESH = 30
    let i = 0
    while (i < viz.cents_error.length) {
      if (Math.abs(viz.cents_error[i]) <= THRESH) { i++; continue }
      const s = i
      while (i < viz.cents_error.length && Math.abs(viz.cents_error[i]) > THRESH) i++
      const e = i - 1
      // safety on indices
      const i0 = viz.idx_ref[s] ?? 0
      const i1 = (viz.idx_ref[e] ?? s) + 1

      const t0 = (i0 * viz.hop) / viz.sr
      const t1 = (i1 * viz.hop) / viz.sr
      if (!isFinite(t0) || !isFinite(t1) || t1 <= t0) continue

      const band = document.createElement("div")
      band.className = "err"
      band.style.left = `${(t0 / T) * 100}%`
      band.style.width = `${((t1 - t0) / T) * 100}%`
      el.appendChild(band)
    }

    // cleanup on unmount/re-render
    return () => { if (ref.current) ref.current.innerHTML = "" }
  }, [viz])

  const noData =
    !viz ||
    !viz.idx_ref?.length ||
    !viz.cents_error?.length ||
    !viz.sr || !viz.hop

  return (
    <div className="card">
      <h2>Pitch Error Timeline</h2>
      <div ref={ref} className="piano" />
      <p className="small">
        {noData
          ? "Upload files and click Analyze to see the timeline."
          : "Red areas: where pitch error > 30 cents (practice these first)."}
      </p>
    </div>
  )
}
