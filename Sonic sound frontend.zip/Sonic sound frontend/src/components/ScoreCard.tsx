import React from "react"

type Score = Partial<{
  overall: number
  pitch: number
  timing: number
  stability: number
  dynamics: number
}>

type Metrics = Partial<{
  median_pitch_error_cents: number
  p95_pitch_error_cents: number
  timing_mae_ms: number
  loudness_corr: number
}>

function fmtNum(x: unknown, digits = 1, fallback = "-") {
  // only format finite numbers
  return (typeof x === "number" && Number.isFinite(x))
    ? x.toFixed(digits)
    : fallback
}

function band(v: unknown) {
  const n = (typeof v === "number" && Number.isFinite(v)) ? v : 0
  return n >= 85 ? "good" : n >= 60 ? "ok" : "bad"
}

export default function ScoreCard({
  score,
  metrics
}: {
  score: Score | null | undefined
  metrics: Metrics | null | undefined
}) {
  const s = score ?? {}
  const m = metrics ?? {}

  return (
    <div className="card">
      <h2>Scores</h2>

      <div className="grid">
        <div className="kpi">
          <h3>Overall</h3>
          <div className={`v ${band(s.overall)}`}>{fmtNum(s.overall, 0)}</div>
        </div>
        <div className="kpi">
          <h3>Pitch</h3>
          <div className={`v ${band(s.pitch)}`}>{fmtNum(s.pitch, 0)}</div>
        </div>
        <div className="kpi">
          <h3>Timing</h3>
          <div className={`v ${band(s.timing)}`}>{fmtNum(s.timing, 0)}</div>
        </div>
        <div className="kpi">
          <h3>Stability</h3>
          <div className={`v ${band(s.stability)}`}>{fmtNum(s.stability, 0)}</div>
        </div>
        <div className="kpi">
          <h3>Dynamics</h3>
          <div className={`v ${band(s.dynamics)}`}>{fmtNum(s.dynamics, 0)}</div>
        </div>
      </div>

      <p className="small">
        Median pitch error: <b>{fmtNum(m.median_pitch_error_cents, 1)}</b> cents,
        P95: <b>{fmtNum(m.p95_pitch_error_cents, 1)}</b> •
        Timing MAE: <b>{fmtNum(m.timing_mae_ms, 0)}</b> ms •
        Loudness corr: <b>{fmtNum(m.loudness_corr, 2)}</b>
      </p>
    </div>
  )
}
