import React from "react"

type Props = {
  onChange: (ref: File | null, usr: File | null) => void
}

const MAX_MB = 50
const AUDIO_OK = new Set([
  "audio/wav", "audio/x-wav", "audio/mpeg", "audio/mp3", "audio/x-m4a",
  "audio/aac", "audio/ogg", "audio/flac", "audio/webm"
])

export default function Upload({ onChange }: Props) {
  // Selected files
  const [refFile, setRefFile] = React.useState<File | null>(null)
  const [usrFile, setUsrFile] = React.useState<File | null>(null)

  // local error text (won't crash the app)
  const [err, setErr] = React.useState<string | null>(null)

  const refInput = React.useRef<HTMLInputElement | null>(null)
  const usrInput = React.useRef<HTMLInputElement | null>(null)

  // Notify parent whenever files change
  React.useEffect(() => {
    onChange(refFile, usrFile)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refFile, usrFile]) // onChange is stable from parent; safe to omit

  const validate = (f: File | null) => {
    if (!f) return { ok: true }
    const tooBig = f.size > MAX_MB * 1024 * 1024
    const typeBad = f.type && !AUDIO_OK.has(f.type)
    if (tooBig) return { ok: false, msg: `File too large (>${MAX_MB} MB).` }
    if (typeBad) return { ok: false, msg: `Unsupported type: ${f.type || "unknown"}` }
    return { ok: true }
  }

  const handleRefChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] ?? null
    const v = validate(f)
    if (!v.ok) {
      setErr(v.msg!)
      setRefFile(null)
      // allow selecting same file again
      if (refInput.current) refInput.current.value = ""
      return
    }
    setErr(null)
    setRefFile(f)
  }

  const handleUsrChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] ?? null
    const v = validate(f)
    if (!v.ok) {
      setErr(v.msg!)
      setUsrFile(null)
      if (usrInput.current) usrInput.current.value = ""
      return
    }
    setErr(null)
    setUsrFile(f)
  }

  const clearRef = () => {
    setRefFile(null)
    if (refInput.current) refInput.current.value = ""
  }
  const clearUsr = () => {
    setUsrFile(null)
    if (usrInput.current) usrInput.current.value = ""
  }

  return (
    <div className="card">
      <h2>Upload Files</h2>

      {err && <div className="card bad" style={{marginTop:8}}>{err}</div>}

      <label>Reference (song/vocal stem) – WAV/MP3</label>
      <div className="row">
        <input
          ref={refInput}
          type="file"
          accept="audio/*"
          onChange={handleRefChange}
        />
        {refFile && (
          <button type="button" onClick={clearRef} title="Clear reference">
            Clear
          </button>
        )}
      </div>
      <p className="small">
        {refFile ? `Selected: ${refFile.name} (${(refFile.size/1048576).toFixed(1)} MB)` : "No file selected"}
      </p>

      <label>Your Recording (mic) – WAV/MP3</label>
      <div className="row">
        <input
          ref={usrInput}
          type="file"
          accept="audio/*"
          onChange={handleUsrChange}
        />
        {usrFile && (
          <button type="button" onClick={clearUsr} title="Clear recording">
            Clear
          </button>
        )}
      </div>
      <p className="small">
        {usrFile ? `Selected: ${usrFile.name} (${(usrFile.size/1048576).toFixed(1)} MB)` : "No file selected"}
      </p>

      <p className="small">
        Tip: Prefer clean mono WAV/MP3 ≤ {MAX_MB} MB. Quiet room + headset mic gives best results.
      </p>
    </div>
  )
}
